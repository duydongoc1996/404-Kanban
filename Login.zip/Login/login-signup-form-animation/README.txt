A Pen created at CodePen.io. You can find this one at https://codepen.io/shayanea/pen/eVMMgO.

 based on https://www.instagram.com/p/Bb7fqgFlTlu