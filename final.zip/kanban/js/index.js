/* Custom Dragula JS */
dragula_obj = dragula([
  document.getElementById("to-do"),
  document.getElementById("doing"),
  document.getElementById("done"),
  document.getElementById("trash")
]);
removeOnSpill: false
  .on("drag", function(el) {
    el.className.replace("ex-moved", "");
  })
  .on("drop", function(el) {
    el.className += "ex-moved";
  })
  .on("over", function(el, container) {
    container.className += "ex-over";
  })
  .on("out", function(el, container) {
    container.className.replace("ex-over", "");
  });

/* Vanilla JS to add a new task */
function addTask() {
  /* Get task text from input */
  var inputTask = document.getElementById("taskText").value;
  /* Add task to the 'To Do' column */
  document.getElementById("to-do").innerHTML +=
    "<li class='task'><p>" + inputTask + "</p></li>";
  /* Clear task text from input after adding task */
  document.getElementById("taskText").value = "";
}

/* Vanilla JS to delete tasks in 'Trash' column */
function emptyTrash() {
  /* Clear tasks from 'Trash' column */
  document.getElementById("trash").innerHTML = "";
}

function addColumn(){
    var col_name = document.getElementById("columnText");
    var column = document.createElement("li");
    column.classList.add("column");
    column.classList.add("to-do-column");
    column.classList.add(col_name+"-column");

      var header = document.createElement("div");
      header.classList.add("column-header");
        var h4 = document.createElement("h4");
        h4.innerHTML = col_name;
      header.appendChild(h4);
      //var tasklist = document.createElement("ul");
      //tasklist.classList.add("task-list");
      //tasklist.id = col_name;
    column.appendChild(header);
    //column.appendChild(tasklist);


    columns = document.getElementsByClassName("columns");

    columns[0].appendChild(column);


    dragula_obj.containers.push(column);
}

